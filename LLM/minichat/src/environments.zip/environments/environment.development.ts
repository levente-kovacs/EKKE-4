export const environment = {
  production: false,
  apiUrl: 'https://api-inference.huggingface.co/models/microsoft/Phi-3.5-mini-instruct',
  huggingfaceApiKey: 'Bearer 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'

};
