package y2xwhj_pt_beadando.interfaces;

public interface Talk {

    String greet();

    String tellFullName();

    String tellAge();
    
}