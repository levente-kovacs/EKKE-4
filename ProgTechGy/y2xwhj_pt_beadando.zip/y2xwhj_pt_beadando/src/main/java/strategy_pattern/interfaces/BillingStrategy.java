package strategy_pattern.interfaces;

public interface  BillingStrategy {
    double getFinalAmount(double rawAmount);
}
