package prog_to_interface.interfaces;

public interface Printer {
    void print(String text);
}
