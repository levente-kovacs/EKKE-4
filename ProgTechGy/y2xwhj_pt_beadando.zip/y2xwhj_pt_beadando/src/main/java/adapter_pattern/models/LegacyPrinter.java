package adapter_pattern.models;

public class LegacyPrinter {
    public void printText(String text) {
        System.out.println("Legacy Printer is printing: " + text);
    }
}
