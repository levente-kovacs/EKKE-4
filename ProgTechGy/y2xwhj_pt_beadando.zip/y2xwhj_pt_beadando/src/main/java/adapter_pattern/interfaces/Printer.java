package adapter_pattern.interfaces;

public interface Printer {
    void print(String text);
}
